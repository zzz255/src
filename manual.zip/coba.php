
<!DOCTYPE html>
<html amp lang="id">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- BAPAKU BAPAKMU! -->
    <meta charset="utf-8" />
    <title>PlayMe8 - Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa</title>
    <link rel="icon" type="image/x-icon" href="https://presidenri888.loggesys.com/src/fav.png" />
    <link rel="canonical" href="https://presidenri888.loggesys.com/" />
    <meta property="og:site_name" content="PLAYME8" />
    <meta property="og:title" content="PlayMe8 - Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa" />
    <meta property="og:url" content="https://presidenri888.loggesys.com/" />
    <meta property="og:type" content="product" />
    <meta property="og:description" content="Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa dari PlayMe8, Dapatkan JP Slot X75-200 di berbagai macam permainan slot yang kami sediakan, depo 10000 kalian sudah bisa WD ratusan jutaan loh, ayo daftar sekarang" />
    <meta property="og:image" content="https://presidenri888.loggesys.com/src/slot-100-jp.webp" />
    <meta property="og:image:width" content="1024" />
    <meta property="og:image:height" content="1024" />
    <meta property="product:price:amount" content="19500.00" />
    <meta property="product:price:currency" content="IDR" />
    <meta property="product:availability" content="instock" />
    <meta itemprop="name" content="PlayMe8 -  Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa" />
    <meta itemprop="url" content="https://presidenri888.loggesys.com/" />
    <meta itemprop="description" content="Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa dari PlayMe8, Dapatkan JP Slot X75-200 di berbagai macam permainan slot yang kami sediakan, depo 10000 kalian sudah bisa WD ratusan jutaan loh, ayo daftar sekarang" />
    <meta itemprop="thumbnailUrl" content="https://presidenri888.loggesys.com/src/slot-100-jp.webp" />
    <link rel="image_src" href="https://presidenri888.loggesys.com/src/slot-100-jp.webp" />
    <meta itemprop="image" content="https://presidenri888.loggesys.com/src/slot-100-jp.webp" />
    <meta name="twitter:title" content="PlayMe8 -  Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa" />
    <meta name="twitter:image" content="https://presidenri888.loggesys.com/src/slot-100-jp.webp" />
    <meta name="twitter:url" content="https://presidenri888.loggesys.com//" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:description" content="Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa dari PlayMe8, Dapatkan JP Slot X75-200 di berbagai macam permainan slot yang kami sediakan, depo 10000 kalian sudah bisa WD ratusan jutaan loh, ayo daftar sekarang" />
    <meta name="description" content="Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa dari PlayMe8, Dapatkan JP Slot X75-200 di berbagai macam permainan slot yang kami sediakan, depo 10000 kalian sudah bisa WD ratusan jutaan loh, ayo daftar sekarang" />
    <link rel="preload" href="https://ik.imagekit.io/slot99/pon-sumut-aceh.webp" as="image" />
    <link rel="preconnect dns-prefetch" href="https://cart.lazada.co.id" />
    <link rel="preconnect dns-prefetch" href="https://acs-m.lazada.co.id" />
    <link rel="preconnect dns-prefetch" href="https://laz-g-cdn.alicdn.com" />
    <link rel="preconnect dns-prefetch" href="https://laz-img-cdn.alicdn.com" />
    <link rel="preconnect dns-prefetch" href="https://assets.alicdn.com" />
    <link rel="preconnect dns-prefetch" href="https://aeis.alicdn.com" />
    <link rel="preconnect dns-prefetch" href="https://aeu.alicdn.com" />
    <link rel="preconnect dns-prefetch" href="https://g.alicdn.com" />
    <link rel="preconnect dns-prefetch" href="https://arms-retcode-sg.aliyuncs.com" />
    <link rel="preconnect dns-prefetch" href="https://px-intl.ucweb.com" />
    <link rel="preconnect dns-prefetch" href="https://sg.mmstat.com" />
    <link rel="preconnect dns-prefetch" href="https://img.lazcdn.comt" />
    <link rel="preconnect dns-prefetch" href="https://g.lazcdn.com" />

    
    <script async src="https://cdn.ampproject.org/v0.js"></script>
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;700&display=swap" />
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;700&display=swap" rel="stylesheet" />
    
    <script type="application/ld+json">
    {"@type":"Product","@context":"https://schema.org","name":"PlayMe8 -  Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa","image":"//id-test-11.slatic.net/p/c08a6637647b6984097e3fcf63c97c3c.jpg","category":"Televisi & Video","brand":{"@type":"Brand","name":"Samsung","url":"https://presidenri888.loggesys.com//"},"sku":"3642482616_ID-6108584955","mpn":3642482616,"description":"Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa dari PlayMe8, Dapatkan JP Slot X75-200 di berbagai macam permainan slot yang kami sediakan, depo 10000 kalian sudah bisa WD ratusan jutaan loh, ayo daftar sekarang","url":"https://www.lazada.co.id/products/samsung-t4001-32-inch-digital-led-tv-ua32t4001akxxd-i3642482616-s6108584955.html","offers":{"@type":"Offer","url":"https://www.lazada.co.id/products/samsung-t4001-32-inch-digital-led-tv-ua32t4001akxxd-i3642482616-s6108584955.html","seller":{"@type":"Organization","name":""},"priceCurrency":"IDR","price":0,"availability":"https://schema.org/InStock","itemCondition":"https://schema.org/NewCondition"}}
  </script>
  <script type="application/ld+json" data-rh="true">
      {
        "@context": "http://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [{
          "@type": "ListItem",
          "position": 1,
          "item": {
            "@id": "https://presidenri888.loggesys.com//",
            "name": "PLAYME8"
          }
        }, {
          "@type": "ListItem",
          "position": 2,
          "item": {
            "@id": "https://presidenri888.loggesys.com//",
            "name": "PLAYME8 Slot"
          }
        }, {
          "@type": "ListItem",
          "position": 3,
          "item": {
            "@id": "https://presidenri888.loggesys.com//",
            "name": "PLAYME8 TOGEL"
          }
        }, {
          "@type": "ListItem",
          "position": 4,
          "item": {
            "@id": "https://presidenri888.loggesys.com//",
            "name": "PLAYME8 Login"
          }
        }, {
          "@type": "ListItem",
          "position": 5,
          "item": {
            "@id": "https://presidenri888.loggesys.com//",
            "name": "PlayMe8 -  Slot Gacor Hari Ini Server Luar​, Deposit via gopay, dana dan pulsa"
          }
        }]
      }
    </script>
    <style amp-boilerplate>
      body {
        -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        animation: -amp-start 8s steps(1, end) 0s 1 normal both;
      }
      @-webkit-keyframes -amp-start {
        from {
          visibility: hidden;
        }
        to {
          visibility: visible;
        }
      }
      @-moz-keyframes -amp-start {
        from {
          visibility: hidden;
        }
        to {
          visibility: visible;
        }
      }
      @-ms-keyframes -amp-start {
        from {
          visibility: hidden;
        }
        to {
          visibility: visible;
        }
      }
      @-o-keyframes -amp-start {
        from {
          visibility: hidden;
        }
        to {
          visibility: visible;
        }
      }
      @keyframes -amp-start {
        from {
          visibility: hidden;
        }
        to {
          visibility: visible;
        }
      }
    </style>
    <noscript>
      <style amp-boilerplate>
        body {
          -webkit-animation: none;
          -moz-animation: none;
          -ms-animation: none;
          animation: none;
        }
      </style>
    </noscript>
    <style amp-custom>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      :focus {
        outline: 0;
      }
      ::-webkit-scrollbar {
        display: none;
      }
      a,
      a:after,
      a:hover,
      a:visited {
        text-decoration: none;
        color: #fff;
      }
      html {
        margin: 0 auto;
        background-color: #000;
      }
      body {
        color: #fff;
        font-family: "Noto Sans", arial, sans-serif;
      }
      .gasss {
        display: grid;
        min-height: 100vh;
      }
      .naikkan {
        margin: auto;
        text-align: center;
      }
      .brody {
        display: inline-grid;
        margin: 0.88rem 0;
      }
      .brody .contole {
        padding: 0.5rem 3.8rem;
        background: #33333388;
        margin-bottom: 0.5rem;
        box-shadow: 0 -1px #ccb38a88;
        letter-spacing: 1px;
      }
      .brody a.btn1 {
        color: #eee;
        background-image: linear-gradient(-45deg, #ffffe0 0, #ffffe0 100%);
        box-shadow: none;
        font-weight: 700;
      }
      .imghero {
        box-shadow: inset 0 0 0 8px #888;
        border-radius: 8px;
      }
      .situs-toto-container {
        display: flex;
        background: linear-gradient(-45deg, #ffffe0 0, #ffffe0 100%);
        width: 250px;
        height: 40px;
        align-items: center;
        justify-content: space-around;
        border-radius: 10px;
        margin: auto;
      }
      .situs-toto {
        outline: 0;
        border: 0;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: transparent;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        transition: all ease-in-out 0.3s;
        cursor: pointer;
      }
      .situs-toto:hover {
        transform: translateY(-3px);
      }
      .icon {
        font-size: 20px;
      }
      .btn2 {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 13rem;
        overflow: hidden;
        height: 3rem;
        background-size: 300% 300%;
        backdrop-filter: blur(1rem);
        border-radius: 0.38rem;
        transition: 0.5s;
        animation: gradient_301 5s ease infinite;
        border: double 4px transparent;
        background-image: linear-gradient(#212121, #212121), linear-gradient(137.48deg, #ffdb3b 10%, #fe53bb 45%, #8f51ea 67%, #04f 87%);
        background-origin: border-box;
        background-clip: content-box, border-box;
      }
      #container-stars {
        position: absolute;
        z-index: -1;
        width: 100%;
        height: 100%;
        overflow: hidden;
        transition: 0.5s;
        backdrop-filter: blur(1rem);
        border-radius: 0.38rem;
      }
      strong {
        z-index: 2;
        letter-spacing: 2px;
        color: #ffffff;
        text-shadow: #00eeff;
      }
      #glow {
        position: absolute;
        display: flex;
        width: 12rem;
      }
      .circle {
        width: 100%;
        height: 30px;
        filter: blur(2rem);
        animation: pulse_3011 4s infinite;
        z-index: -1;
      }
      .circle:nth-of-type(1) {
        background: rgba(254, 83, 186, 0.636);
      }
      .circle:nth-of-type(2) {
        background: rgba(142, 81, 234, 0.704);
      }
      .btn2:hover #container-stars {
        z-index: 1;
        background-color: #212121;
      }
      .btn2:hover {
        transform: scale(1.1);
      }
      .btn2:active {
        border: double 4px #fe53bb;
        background-origin: border-box;
        background-clip: content-box, border-box;
        animation: none;
      }
      .btn2:active .circle {
        background: #fe53bb;
      }
      #stars {
        position: relative;
        background: 0 0;
        width: 200rem;
        height: 200rem;
      }
      #stars::after {
        content: "";
        position: absolute;
        top: -10rem;
        left: -100rem;
        width: 100%;
        height: 100%;
        animation: animStarRotate 90s linear infinite;
      }
      #stars::after {
        background-image: radial-gradient(#fff 1px, transparent 1%);
        background-size: 50px 50px;
      }
      #stars::before {
        content: "";
        position: absolute;
        top: 0;
        left: -50%;
        width: 170%;
        height: 500%;
        animation: animStar 60s linear infinite;
      }
      #stars::before {
        background-image: radial-gradient(#fff 1px, transparent 1%);
        background-size: 50px 50px;
        opacity: 0.5;
      }
      @keyframes animStar {
        from {
          transform: translateY(0);
        }
        to {
          transform: translateY(-135rem);
        }
      }
      @keyframes animStarRotate {
        from {
          transform: rotate(360deg);
        }
        to {
          transform: rotate(0);
        }
      }
      @keyframes gradient_301 {
        0% {
          background-position: 0 50%;
        }
        50% {
          background-position: 100% 50%;
        }
        100% {
          background-position: 0 50%;
        }
      }
      @keyframes pulse_3011 {
        0% {
          transform: scale(0.75);
          box-shadow: 0 0 0 0 rgba(0, 0, 0, 0.7);
        }
        70% {
          transform: scale(1);
          box-shadow: 0 0 0 10px transparent;
        }
        100% {
          transform: scale(0.75);
          box-shadow: 0 0 0 0 transparent;
        }
      }
      .amp-img {
        position: relative;
        margin: auto;
        min-width: 100px;
        padding: 5px 10px;
        background: linear-gradient(0deg, #000, #272727);
        color: #fff;
        cursor: pointer;
        margin-bottom: 20px;
      }
      .block {
        position: relative;
        margin: auto 0;
        width: 280px;
        padding: 10px 16px;
        background: linear-gradient(0deg, #000, #272727);
        color: #fff;
        cursor: pointer;
        margin-bottom: 14px;
        border-radius: 10px;
      }
      .block:before,
      .block:after {
        content: "";
        position: absolute;
        right: -3px;
        bottom: -3px;
        background: linear-gradient(45deg, #ff0000, #ff7300, #fbff00, #1eff00, #0077ff, #7700ff, #ff00d4, #ff0000);
        background-size: 400%;
        width: calc(100% + 6px);
        height: calc(100% + 6px);
        z-index: -1;
        border-radius: 12px;
        animation: steam 10s linear infinite;
      }
      .amp-img:before,
      .amp-img:after {
        content: "";
        position: relative;
        right: -3px;
        bottom: -3px;
        background: linear-gradient(45deg, #ff0000, #ff7300, #fbff00, #1eff00, #0077ff, #7700ff, #ff00d4, #ff0000);
        background-size: 400%;
        width: calc(100% + 6px);
        height: calc(100% + 6px);
        z-index: -1;
        animation: steam 3s linear infinite;
      }

      @keyframes steam {
        0% {
          background-position: 0 0;
        }
        50% {
          background-position: 400% 0;
        }
        100% {
          background-position: 0 0;
        }
      }

      .block:after {
        filter: blur(50px);
      }
      #image {
        display: block;
        margin: 0.2rem auto;
        border-radius: 1rem;
      }
    </style>
  </head>
  <body>
    <main>
      <div class="gasss">
        <div class="naikkan">
          <br />
          <div>
            <amp-img id="image" height="400" width="400" alt="PLAYME8" src="https://presidenri888.loggesys.com/src/slot-100-jp.webp"></amp-img>
          </div>
          <br>
          <div class="brody">
            <a href="https://playme107.net/?inviteCode=FrTfLuM" target="_blank" rel="noopener noreferrer nofollow" class="block">DAFTAR </a>
            <a href="https://playme107.net/?inviteCode=FrTfLuM" target="_blank" rel="noopener noreferrer nofollow" class="block">LOGIN </a>
            <a href="https://playme107.net/?inviteCode=FrTfLuM" target="_blank" rel="noopener noreferrer nofollow" class="block">VIP GACOR</a>
			<a href="https://hashtech.co.tz/gac0r/" class="block">Link Alternatif Slot Gacor</a>
          </div>
        </div>
        <span style="text-align: center; color: #ffffff">&copy;<a href="https://presidenri888.loggesys.com/" style="color: #d0ff00">PlayMe8</a> - Link Alternatif Resmi</span>
      </div>
    </main>
    
        <!-- Histats.com START (hidden counter) -->
    <amp-img src="//sstatic1.histats.com/0.gif?4900158&101"
              width="1"
              height="1"
              alt=""
              layout="fixed"></amp-img>
    <!-- Histats.com END -->
    
  </body>
</html>
